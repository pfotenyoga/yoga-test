(function () {
'use strict';

/* ---------- Konstanten ---------- */
var TYPES = {
  welpen: { label: 'Welpenyoga', cls: 'pup', blurb: 'Kleine Termine mit den Welpen des Studios. Die Welpen bestimmen das Tempo und dürfen sich jederzeit zurückziehen.' },
  hund: { label: 'Mit eigenem Hund', cls: 'dog', blurb: 'Du bringst deinen Hund mit. Impfschutz, Haftpflicht und Verträglichkeit sind Voraussetzung.' },
  ohne: { label: 'Ohne Hund', cls: 'nodog', blurb: 'Yoga ohne Tiere im Raum.' }
};
var LEVELS = ['Alle Level', 'Einsteiger', 'Fortgeschritten'];
var PAY = { online: 'Online bezahlen', paypal: 'PayPal', bar: 'Bar vor Ort', karte: 'Karte vor Ort', ueberweisung: 'Überweisung' };
var ROLE_LABEL = { customer: 'Kunde', trainer: 'Trainer/in', admin: 'Admin' };
var COURSE_LABELS = { title: 'Titel', type: 'Kursart', date: 'Datum', time: 'Uhrzeit', dur: 'Dauer', cap: 'Plätze', price: 'Preis', level: 'Niveau', description: 'Beschreibung', status: 'Status' };
var PROFILE_LABELS = { name: 'Name', styles: 'Yoga-Stile', bio: 'Über mich', dog_ok: 'Erfahrung mit Hunden' };
var NEEDS_USER = ['buchungen', 'konto', 'trainer', 'admin'];
var PUBLIC_ROUTES = ['kurse', 'kalender', 'team', 'raum', 'buchungen', 'konto', 'trainer', 'admin', 'login', 'registrieren', 'passwort-vergessen', 'passwort-neu', 'rechtliches'];

var S = {
  ready: false, user: null, config: { stripe: false, cancel_hours: 24, requirements: { welpen: [], hund: [], ohne: [] } },
  courses: [], room: null, trainers: [], mine: [], adm: null, tr: null,
  filter: 'all', calMonth: null, calDay: null, adminTab: 'freigaben', trainerTab: 'profil',
  editing: null, formDirty: false, next: null, heroSeen: false, error: '', lang: 'de'
};
function LOC() { return S.lang === 'en' ? 'en-GB' : 'de-DE'; }
function initLang() {
  var l = '';
  try { l = localStorage.getItem('lang') || ''; } catch (e) {}
  if (l !== 'de' && l !== 'en') l = /^de/i.test(navigator.language || '') ? 'de' : 'en';
  S.lang = l; document.documentElement.lang = l;
}
function setLang(l) {
  if (l === S.lang) return;
  S.lang = l; document.documentElement.lang = l;
  try { localStorage.setItem('lang', l); } catch (e) {}
  if (S.user) api('POST', '/api/me/lang', { lang: l }).catch(function () {});
  closeModal(); S.formDirty = false; S.editing = null;
  render();
}

/* ---------- Helfer ---------- */
function $(s) { return document.querySelector(s); }
function h(tag, attrs) {
  var e = document.createElement(tag), val;
  attrs = attrs || {};
  Object.keys(attrs).forEach(function (k) {
    var v = attrs[k];
    if (v == null || v === false) return;
    if (k === 'class') e.className = v;
    else if (k === 'value') val = v;
    else if (k === 'checked') e.checked = !!v;
    else if (k === 'disabled') e.disabled = !!v;
    else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : String(v));
  });
  for (var i = 2; i < arguments.length; i++) add(e, arguments[i]);
  if (val !== undefined) e.value = val;
  return e;
}
function add(e, c) {
  if (c == null || c === false) return;
  if (Array.isArray(c)) { c.forEach(function (x) { add(e, x); }); return; }
  e.append(c.nodeType ? c : document.createTextNode(String(c)));
}
function toast(msg) {
  var t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toast.t); toast.t = setTimeout(function () { t.hidden = true; }, 4200);
}
function todayISO() { return new Date().toLocaleDateString('sv-SE', { timeZone: 'Europe/Madrid' }); }
function dparts(iso) {
  var d = new Date(iso + 'T12:00:00Z'), o = { timeZone: 'UTC' };
  return {
    wd: d.toLocaleDateString(LOC(), Object.assign({ weekday: 'short' }, o)), day: d.getUTCDate(),
    mon: d.toLocaleDateString(LOC(), Object.assign({ month: 'short' }, o)),
    full: d.toLocaleDateString(LOC(), Object.assign({ weekday: 'long', day: 'numeric', month: 'long' }, o))
  };
}
function euro(cents) {
  return (cents / 100).toLocaleString(LOC(), { style: 'currency', currency: 'EUR', minimumFractionDigits: cents % 100 ? 2 : 0, maximumFractionDigits: 2 });
}
function fmtVal(k, v) {
  if (v == null || v === '') return '–';
  if (k === 'type') return (TYPES[v] || {}).label || v;
  if (k === 'price') return euro(Number(v) * 100);
  if (k === 'dur') return v + ' Min.';
  if (k === 'dog_ok') return v ? 'Ja' : 'Nein';
  return String(v);
}
function fld(label, ctrl, hint) { return h('label', { class: 'fld' }, h('span', { class: 'fl' }, label), ctrl, hint ? h('small', null, hint) : null); }

/* ---------- Schnittstelle ---------- */
function api(method, url, body, raw) {
  var init = { method: method, headers: { 'X-Lang': S.lang }, credentials: 'same-origin' };
  if (raw) { init.headers['Content-Type'] = raw.type || 'application/octet-stream'; init.body = raw; }
  else if (body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
  return fetch(url, init).then(function (res) {
    return res.json().catch(function () { return null; }).then(function (data) {
      if (!res.ok) {
        var err = new Error((data && data.message) || 'Das hat nicht geklappt. Bitte versuche es noch einmal.');
        err.code = data && data.error; err.status = res.status;
        if (res.status === 401 && S.user) { S.user = null; S.mine = []; render(); }
        throw err;
      }
      return data;
    });
  });
}
/** Führt eine Aktion aus, meldet Fehler als Hinweis und lädt danach alles neu */
function act(fn, okMsg) {
  return Promise.resolve().then(fn).then(function (r) {
    if (okMsg) toast(okMsg);
    return reload().then(function () { return r; });
  }).catch(function (e) { toast(e.message); throw e; });
}
function loadPublic() {
  return Promise.all([api('GET', '/api/courses'), api('GET', '/api/room'), api('GET', '/api/trainers')]).then(function (r) {
    S.courses = r[0].courses; S.room = r[1]; S.trainers = r[2].trainers;
  });
}
function loadUserData() {
  if (!S.user) { S.mine = []; S.adm = null; S.tr = null; return Promise.resolve(); }
  var jobs = [api('GET', '/api/bookings/mine').then(function (r) { S.mine = r.bookings; })];
  if (S.user.role === 'admin') jobs.push(api('GET', '/api/admin/overview').then(function (r) { S.adm = r; }));
  if (S.user.role === 'trainer') jobs.push(api('GET', '/api/trainer/overview').then(function (r) { S.tr = r; }));
  return Promise.all(jobs);
}
function reload() {
  S.formDirty = false; S.editing = S.editing && S.editing.keep ? S.editing : null;
  return Promise.all([loadPublic(), loadUserData()]).then(function () { render(); });
}

/* ---------- Routing ---------- */
function currentRoute() {
  var raw = location.hash.replace(/^#/, ''), i = raw.indexOf('?');
  var name = i < 0 ? raw : raw.slice(0, i), q = new URLSearchParams(i < 0 ? '' : raw.slice(i + 1));
  if (PUBLIC_ROUTES.indexOf(name) < 0) name = 'kurse';
  return { name: name, q: q };
}
function go(name, query) {
  S.formDirty = false; S.editing = null;
  location.hash = '#' + name + (query ? '?' + query : '');
  window.scrollTo(0, 0);
}
window.addEventListener('hashchange', function () { S.formDirty = false; S.editing = null; render(); });

/* ---------- Rahmen ---------- */
function pendingCount() { return S.adm ? S.adm.proposals.length + S.adm.trainerRequests.length : 0; }
function renderNav(r) {
  var nav = $('#nav'); nav.replaceChildren();
  var tabs = [['kurse', 'Kurse'], ['kalender', 'Kalender'], ['team', 'Team'], ['raum', 'Der Raum']];
  if (S.user) tabs.push(['buchungen', 'Meine Buchungen']);
  if (S.user && S.user.role === 'trainer') tabs.push(['trainer', 'Für Trainer']);
  if (S.user && S.user.role === 'customer') tabs.push(['trainer', 'Trainer werden']);
  if (S.user && S.user.role === 'admin') tabs.push(['admin', 'Verwaltung']);
  tabs.forEach(function (t) {
    var n = t[0] === 'admin' ? pendingCount() : 0;
    nav.append(h('button', { type: 'button', 'aria-current': r.name === t[0] ? 'page' : null, onclick: function () { go(t[0]); } }, t[1], n ? h('span', { class: 'count' }, n) : null));
  });
  nav.append(h('span', { class: 'spacer' }));
  nav.append(h('span', { class: 'lang', role: 'group', 'aria-label': 'Sprache / Language' }, ['de', 'en'].map(function (l) {
    return h('button', { type: 'button', lang: l, 'aria-pressed': String(S.lang === l), onclick: function () { setLang(l); } }, l.toUpperCase());
  })));
  nav.append(S.user
    ? h('button', { type: 'button', class: 'account', 'aria-current': r.name === 'konto' ? 'page' : null, onclick: function () { go('konto'); } }, S.user.name || 'Konto')
    : h('button', { type: 'button', class: 'account', 'aria-current': r.name === 'login' ? 'page' : null, onclick: function () { go('login'); } }, 'Anmelden'));
}
function renderFoot() {
  var f = $('#foot'); f.replaceChildren(
    h('span', null, (S.room && S.room.studio_name) || 'Yoga mit Pfoten'),
    h('a', { href: '#rechtliches' }, 'Impressum, Datenschutz, AGB')
  );
}

function render() {
  S.formDirty = false;
  var r = currentRoute(), v = $('#view');
  document.title = (S.room && S.room.studio_name) || 'Yoga mit Pfoten';
  if (S.room) { $('#studio').textContent = S.room.studio_name; $('#tagline').textContent = S.room.tagline; }
  if (!S.ready) { v.replaceChildren(h('p', { class: 'muted' }, S.error || 'Lädt …')); return; }
  if (NEEDS_USER.indexOf(r.name) > -1 && !S.user) { S.next = r.name; location.replace('#login'); return; }
  renderNav(r); renderFoot();
  v.replaceChildren();
  if (S.user && !S.user.email_verified) {
    v.append(h('div', { class: 'banner' }, h('span', null, 'Bitte bestätige deine E-Mail-Adresse, damit du Kurse buchen kannst. Wir haben dir einen Link geschickt.'),
      h('button', { type: 'button', class: 'btn sm', onclick: function () { api('POST', '/api/resend-verification', {}).then(function () { toast('Link ist unterwegs.'); }).catch(function (e) { toast(e.message); }); } }, 'Link erneut senden')));
  }
  var views = { kurse: viewKurse, kalender: viewKalender, team: viewTeam, raum: viewRaum, buchungen: viewBuchungen, konto: viewKonto, trainer: viewTrainer, admin: viewAdmin,
    login: viewLogin, registrieren: viewRegister, 'passwort-vergessen': viewForgot, 'passwort-neu': viewReset, rechtliches: viewLegal };
  views[r.name](v, r);
}
function afterInput(form) { form.addEventListener('input', function () { S.formDirty = true; }); return form; }

/* ---------- Konto: Anmelden, Registrieren ---------- */
function authDone(res) {
  S.user = res.user;
  api('POST', '/api/me/lang', { lang: S.lang }).catch(function () {});
  return loadUserData().then(function () { var n = S.next || 'kurse'; S.next = null; go(n); toast('Willkommen, ' + (S.user.name || 'schön dass du da bist') + '.'); });
}
function viewLogin(v) {
  var email = h('input', { id: 'li-email', type: 'email', required: true, autocomplete: 'email' });
  var pw = h('input', { id: 'li-pw', type: 'password', required: true, autocomplete: 'current-password' });
  var msg = h('p', { class: 'small', role: 'alert' });
  v.append(afterInput(h('form', { class: 'panel narrow stack', onsubmit: function (e) {
    e.preventDefault(); msg.textContent = '';
    api('POST', '/api/login', { email: email.value, password: pw.value }).then(authDone).catch(function (err) { msg.textContent = err.message; });
  } },
    h('h2', null, 'Anmelden'),
    fld('E-Mail', email), fld('Passwort', pw), msg,
    h('button', { type: 'submit', class: 'btn primary' }, 'Anmelden'),
    h('p', { class: 'small' }, h('a', { href: '#passwort-vergessen' }, 'Passwort vergessen?')),
    h('p', { class: 'small' }, 'Noch kein Konto? ', h('a', { href: '#registrieren' }, 'Jetzt registrieren')))));
}
function viewRegister(v) {
  var name = h('input', { id: 'rg-name', type: 'text', required: true, maxlength: 60, autocomplete: 'name' });
  var email = h('input', { id: 'rg-email', type: 'email', required: true, autocomplete: 'email' });
  var pw = h('input', { id: 'rg-pw', type: 'password', required: true, minlength: 8, autocomplete: 'new-password' });
  var msg = h('p', { class: 'small', role: 'alert' });
  v.append(afterInput(h('form', { class: 'panel narrow stack', onsubmit: function (e) {
    e.preventDefault(); msg.textContent = '';
    api('POST', '/api/register', { name: name.value, email: email.value, password: pw.value }).then(authDone).catch(function (err) { msg.textContent = err.message; });
  } },
    h('h2', null, 'Konto anlegen'),
    h('p', { class: 'muted' }, 'Mit einem Konto buchst du Kurse und siehst deine Termine. Wir schicken dir einen Link zur Bestätigung deiner E-Mail-Adresse.'),
    fld('Name', name), fld('E-Mail', email), fld('Passwort', pw, 'Mindestens 8 Zeichen.'), msg,
    h('button', { type: 'submit', class: 'btn primary' }, 'Konto anlegen'),
    h('p', { class: 'small' }, 'Schon ein Konto? ', h('a', { href: '#login' }, 'Anmelden')))));
}
function viewForgot(v) {
  var email = h('input', { id: 'fg-email', type: 'email', required: true, autocomplete: 'email' });
  var done = h('p', { class: 'banner ok', hidden: true }, 'Wenn es ein Konto mit dieser Adresse gibt, ist ein Link zum Zurücksetzen unterwegs.');
  v.append(afterInput(h('form', { class: 'panel narrow stack', onsubmit: function (e) {
    e.preventDefault();
    api('POST', '/api/forgot', { email: email.value }).then(function () { done.hidden = false; }).catch(function (err) { toast(err.message); });
  } },
    h('h2', null, 'Passwort vergessen'),
    fld('E-Mail', email), done,
    h('button', { type: 'submit', class: 'btn primary' }, 'Link senden'),
    h('p', { class: 'small' }, h('a', { href: '#login' }, 'Zurück zur Anmeldung')))));
}
function viewReset(v, r) {
  var token = r.q.get('token') || '';
  var pw = h('input', { id: 'rs-pw', type: 'password', required: true, minlength: 8, autocomplete: 'new-password' });
  var msg = h('p', { class: 'small', role: 'alert' });
  v.append(afterInput(h('form', { class: 'panel narrow stack', onsubmit: function (e) {
    e.preventDefault(); msg.textContent = '';
    api('POST', '/api/reset', { token: token, password: pw.value }).then(function () { toast('Passwort geändert. Bitte melde dich an.'); S.user = null; go('login'); }).catch(function (err) { msg.textContent = err.message; });
  } },
    h('h2', null, 'Neues Passwort festlegen'),
    fld('Neues Passwort', pw, 'Mindestens 8 Zeichen.'), msg,
    h('button', { type: 'submit', class: 'btn primary' }, 'Passwort speichern'))));
}
function viewKonto(v, r) {
  var u = S.user;
  if (r.q.get('verifiziert')) v.append(h('div', { class: 'banner ok' }, 'Danke, deine E-Mail-Adresse ist bestätigt.'));
  if (r.q.get('fehler')) v.append(h('div', { class: 'banner bad' }, 'Der Link ist abgelaufen oder wurde schon benutzt. Du kannst oben einen neuen anfordern.'));
  var name = h('input', { id: 'ko-name', type: 'text', required: true, maxlength: 60, value: u.name });
  v.append(h('h2', null, 'Mein Konto'));
  v.append(afterInput(h('form', { class: 'panel stack', onsubmit: function (e) {
    e.preventDefault();
    api('POST', '/api/me', { name: name.value }).then(function (res) { S.user = res.user; S.formDirty = false; toast('Gespeichert.'); render(); }).catch(function (err) { toast(err.message); });
  } },
    h('div', { class: 'row' }, h('span', { class: 'chip grey' }, ROLE_LABEL[u.role]), h('span', { class: 'chip ' + (u.email_verified ? 'ok' : 'warn') }, u.email_verified ? 'E-Mail bestätigt' : 'E-Mail nicht bestätigt')),
    h('p', { class: 'muted' }, u.email),
    fld('Name', name),
    h('div', null, h('button', { type: 'submit', class: 'btn primary' }, 'Speichern')))));
  var oldp = h('input', { id: 'ko-old', type: 'password', required: true, autocomplete: 'current-password' });
  var newp = h('input', { id: 'ko-new', type: 'password', required: true, minlength: 8, autocomplete: 'new-password' });
  v.append(afterInput(h('form', { class: 'panel stack', onsubmit: function (e) {
    e.preventDefault();
    api('POST', '/api/me/password', { old_password: oldp.value, new_password: newp.value }).then(function () { S.formDirty = false; toast('Passwort geändert.'); render(); }).catch(function (err) { toast(err.message); });
  } },
    h('h3', null, 'Passwort ändern'),
    h('div', { class: 'grid2' }, fld('Altes Passwort', oldp), fld('Neues Passwort', newp)),
    h('div', null, h('button', { type: 'submit', class: 'btn' }, 'Passwort ändern')))));
  v.append(h('div', null, h('button', { type: 'button', class: 'btn', onclick: function () {
    api('POST', '/api/logout', {}).then(function () { S.user = null; S.mine = []; S.adm = null; S.tr = null; go('kurse'); toast('Du bist abgemeldet.'); });
  } }, 'Abmelden')));
}

/* ---------- Kurse ---------- */
function paw() {
  var ns = 'http://www.w3.org/2000/svg', s = document.createElementNS(ns, 'svg');
  s.setAttribute('viewBox', '0 0 100 100'); s.setAttribute('class', 'paw'); s.setAttribute('aria-hidden', 'true');
  [[22, 38], [42, 22], [62, 22], [80, 38]].forEach(function (p) {
    var e = document.createElementNS(ns, 'ellipse'); e.setAttribute('cx', p[0]); e.setAttribute('cy', p[1]); e.setAttribute('rx', 11); e.setAttribute('ry', 14); e.setAttribute('fill', 'currentColor'); s.append(e);
  });
  var b = document.createElementNS(ns, 'path');
  b.setAttribute('d', 'M50 48c-16 0-30 18-30 30 0 9 8 12 16 10 8-2 10-3 14-3s6 1 14 3c8 2 16-1 16-10 0-12-14-30-30-30z'); b.setAttribute('fill', 'currentColor'); s.append(b);
  return s;
}
function heroBlock(pup, t0) {
  var intro = !S.heroSeen; S.heroSeen = true;
  var next = pup[0], days = next ? Math.round((new Date(next.date + 'T00:00:00Z') - new Date(t0 + 'T00:00:00Z')) / 864e5) : null;
  var left = pup.reduce(function (n, c) { return n + Math.max(0, c.cap - c.taken); }, 0);
  var count = next ? h('div', { class: 'count' },
    days > 0 ? [h('b', null, String(days)), h('span', null, days === 1 ? 'Tag bis zum ersten Welpenyoga' : 'Tage bis zum ersten Welpenyoga')] : [h('b', null, 'Jetzt'), h('span', null, 'läuft das Welpenyoga')],
    h('span', { class: 'small' }, left + ' freie Plätze in ' + pup.length + (pup.length === 1 ? ' Termin' : ' Terminen')),
    h('button', { type: 'button', class: 'btn primary', onclick: function () { S.filter = 'welpen'; render(); } }, 'Welpen-Termine ansehen')) : null;
  return h('section', { class: 'hero' + (intro ? ' rise' : '') }, paw(),
    h('div', { class: 'txt' }, h('p', { class: 'kick' }, (S.room && S.room.studio_name) || 'Yoga mit Pfoten'),
      h('h2', null, 'Yoga, bei dem der Hund mitmacht.'),
      h('p', { class: 'lead' }, 'Welpenyoga mit unseren Welpen, Kurse mit deinem eigenen Hund und klassisches Yoga ohne Fell. Such dir deinen Termin aus.')),
    count);
}
function myBooking(cid) { return S.mine.find(function (b) { return b.course_id === cid; }); }
function courseCard(c) {
  var t = TYPES[c.type] || TYPES.ohne, left = Math.max(0, c.cap - c.taken), mine = myBooking(c.id), d = dparts(c.date), off = c.status === 'abgesagt';
  var act = [h('b', null, euro(c.price_cents))];
  if (off) act.push(h('span', { class: 'chip bad' }, 'Abgesagt'));
  else if (c.starts_at < Date.now()) act.push(h('span', { class: 'chip grey' }, 'Vorbei'));
  else if (mine) act.push(h('span', { class: 'chip ' + (mine.status === 'ok' ? 'ok' : 'warn') }, mine.status === 'ok' ? 'Gebucht' : 'Auf der Warteliste'));
  else if (!S.user) act.push(h('button', { type: 'button', class: 'btn primary sm', onclick: function () { S.next = 'kurse'; go('login'); } }, 'Anmelden zum Buchen'));
  else act.push(h('button', { type: 'button', class: 'btn primary sm', onclick: function () { openBooking(c); } }, left > 0 ? 'Buchen' : 'Warteliste'));
  return h('article', { class: 'card' },
    h('div', { class: 'date', 'aria-hidden': 'true' }, h('span', null, d.wd), h('b', null, d.day), h('span', null, d.mon)),
    h('div', { class: 'info' }, h('span', { class: 'chip ' + t.cls }, t.label), h('h3', null, c.title),
      h('div', { class: 'meta' }, h('span', null, c.time + ' Uhr · ' + c.dur + ' Min.'), h('span', null, 'mit ' + c.trainer_name), h('span', null, c.level),
        off ? null : h('span', null, left > 0 ? 'Noch ' + left + ' von ' + c.cap + ' Plätzen frei' : 'Ausgebucht'), c.example ? h('span', null, 'Beispieltermin') : null),
      c.description ? h('p', { class: 'small' }, c.description) : null),
    h('div', { class: 'act' }, act));
}
function viewKurse(v) {
  var t0 = todayISO();
  var up = S.courses.filter(function (c) { return c.date >= t0; });
  var pup = up.filter(function (c) { return c.type === 'welpen' && c.status !== 'abgesagt'; });
  v.append(heroBlock(pup, t0));
  var opts = [['all', 'Alle Kurse', 'Alle Termine nach Datum.']].concat(Object.keys(TYPES).map(function (k) { return [k, TYPES[k].label, TYPES[k].blurb]; }));
  v.append(h('div', { class: 'filters', role: 'group', 'aria-label': 'Kursart' }, opts.map(function (o) {
    return h('button', { type: 'button', class: 'ftype ' + (o[0] === 'all' ? '' : TYPES[o[0]].cls) + (S.filter === o[0] ? ' on' : ''), 'aria-pressed': String(S.filter === o[0]),
      onclick: function () { S.filter = o[0]; render(); } }, h('strong', null, o[1]), h('span', null, o[2]));
  })));
  var list = up.filter(function (c) { return S.filter === 'all' || c.type === S.filter; });
  if (!list.length) { v.append(h('div', { class: 'panel' }, h('h3', null, 'Keine Termine in dieser Kursart'), h('p', { class: 'muted' }, 'Schau bald wieder vorbei, neue Termine kommen laufend dazu.'))); return; }
  var last = '', box = null;
  list.forEach(function (c) {
    if (c.date !== last) { last = c.date; v.append(h('div', { class: 'dayhead' }, dparts(c.date).full)); box = h('div', { class: 'list' }); v.append(box); }
    box.append(courseCard(c));
  });
}

/* ---------- Buchen ---------- */
function closeModal() { var m = $('#modal'); m.hidden = true; m.replaceChildren(); document.removeEventListener('keydown', escClose); }
function escClose(e) { if (e.key === 'Escape') closeModal(); }
function openBooking(c) {
  if (!S.user.email_verified) { toast('Bitte bestätige zuerst deine E-Mail-Adresse.'); return; }
  var t = TYPES[c.type] || TYPES.ohne, left = Math.max(0, c.cap - c.taken), wait = left < 1, max = wait ? Math.min(c.cap, 1) : Math.min(left, 4);
  var reqs = S.config.requirements[c.type] || [];
  var name = h('input', { id: 'bk-name', type: 'text', required: true, maxlength: 40, autocomplete: 'given-name', value: (S.user.name || '').split(' ')[0] });
  var seats = h('select', { id: 'bk-seats' }, Array.from({ length: max }, function (_, i) { return h('option', { value: i + 1 }, String(i + 1)); }));
  var dog = c.type === 'hund' ? h('input', { id: 'bk-dog', type: 'text', required: true, maxlength: 40 }) : null;
  var methods = (S.config.stripe ? ['online'] : []).concat(S.room && S.room.paypal_me ? ['paypal'] : [], ['bar', 'karte', 'ueberweisung']);
  var pay = h('select', { id: 'bk-pay' }, methods.map(function (k) { return h('option', { value: k }, PAY[k]); }));
  var payNote = h('p', { class: 'small muted' });
  function payText() {
    var total = c.price_cents * (Number(seats.value) || 1), info = (S.room && S.room.pay_info) || '';
    payNote.textContent = 'Gesamtpreis: ' + euro(total) + '. ' + (pay.value === 'ueberweisung' ? (info ? 'Überweisung an: ' + info : 'Die Bankverbindung bekommst du per E-Mail.') : pay.value === 'online' ? 'Nach dem Buchen geht es direkt zur Bezahlseite.' : pay.value === 'paypal' ? 'Nach dem Buchen bekommst du den PayPal-Link und zahlst direkt dort.' : 'Du bezahlst vor Ort.');
  }
  pay.addEventListener('change', payText); seats.addEventListener('change', payText); payText();
  var legalBox = h('label', { class: 'check' }, h('input', { id: 'bk-legal', type: 'checkbox', required: true }), h('span', null, 'Ich habe die ', h('a', { href: '#rechtliches', target: '_blank' }, 'AGB und die Datenschutzerklärung'), ' gelesen und akzeptiere sie.'));
  var boxes = reqs.map(function (r, i) { return h('label', { class: 'check' }, h('input', { id: 'bk-chk' + i, type: 'checkbox', required: true }), h('span', null, r)); });
  var msg = h('p', { class: 'small', role: 'alert' });
  var btn = h('button', { type: 'submit', class: 'btn primary' }, wait ? 'Auf die Warteliste setzen' : 'Verbindlich buchen');
  var form = h('form', { class: 'stack', onsubmit: function (e) {
    e.preventDefault(); msg.textContent = ''; btn.disabled = true;
    api('POST', '/api/bookings', { course_id: c.id, first_name: name.value, seats: Number(seats.value), dog_name: dog ? dog.value : '', pay_method: pay.value, confirmed: true }).then(function (res) {
      closeModal();
      if (res.pay_url) { window.location.href = res.pay_url; return; }
      toast(res.status === 'ok' && pay.value === 'paypal' ? 'Gebucht. Bezahle jetzt unter „Meine Buchungen“ mit PayPal.' : res.status === 'wait' ? 'Du stehst auf der Warteliste. Wir schreiben dir, sobald ein Platz frei wird.' : res.pay_error ? 'Gebucht. Die Zahlungsseite ist gerade nicht erreichbar, du kannst unter „Meine Buchungen“ erneut bezahlen.' : 'Gebucht. Eine Bestätigung ist unterwegs.');
      return reload().then(function () { go('buchungen'); });
    }).catch(function (err) { btn.disabled = false; msg.textContent = err.message; });
  } },
    h('div', { class: 'grid2' }, fld('Vorname', name), fld('Plätze', seats)),
    dog ? fld('Name des Hundes', dog) : null,
    fld('Zahlungsart', pay), payNote,
    h('div', { class: 'list' }, boxes.concat([legalBox])), msg,
    h('div', { class: 'row' }, btn, h('button', { type: 'button', class: 'btn', onclick: closeModal }, 'Abbrechen')));
  var m = $('#modal');
  m.replaceChildren(h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Kurs buchen' },
    h('span', { class: 'chip ' + t.cls }, t.label), h('h2', null, c.title),
    h('p', { class: 'muted' }, dparts(c.date).full + ', ' + c.time + ' Uhr' + (wait ? '. Der Kurs ist ausgebucht, du rückst nach, sobald ein Platz frei wird.' : '')), form));
  m.hidden = false; m.onclick = function (e) { if (e.target === m) closeModal(); };
  document.addEventListener('keydown', escClose); name.focus();
}

/* ---------- Kalender ---------- */
function deleteBtn(c) {
  var b = h('button', { type: 'button', class: 'btn sm danger', onclick: function () {
    if (!b.dataset.arm) { b.dataset.arm = '1'; b.textContent = 'Wirklich löschen?'; return; }
    act(function () { return api('DELETE', '/api/admin/courses/' + c.id); }, 'Kurs gelöscht.').catch(function () {});
  } }, 'Löschen');
  return b;
}
function adminActions(card, c) {
  card.querySelector('.act').replaceChildren(h('b', null, euro(c.price_cents)),
    h('button', { type: 'button', class: 'btn sm', onclick: function () { S.editing = { course: c }; render(); } }, 'Bearbeiten'), deleteBtn(c));
  return card;
}
function viewKalender(v) {
  if (S.user && S.user.role === 'admin' && S.editing) { v.append(adminCourseForm()); return; }
  var t0 = todayISO(), ym = S.calMonth || t0.slice(0, 7), pr = ym.split('-'), y = +pr[0], m = +pr[1] - 1;
  var first = new Date(Date.UTC(y, m, 1)), offset = (first.getUTCDay() + 6) % 7, days = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  function shift(n) { var d = new Date(Date.UTC(y, m + n, 1)); S.calMonth = d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0'); S.calDay = null; render(); }
  var by = {};
  S.courses.forEach(function (c) { (by[c.date] = by[c.date] || []).push(c); });
  var sel = S.calDay;
  if (!sel || sel.slice(0, 7) !== ym) {
    var cand = Object.keys(by).filter(function (k) { return k.slice(0, 7) === ym && k >= t0; }).sort()[0];
    sel = cand || (ym === t0.slice(0, 7) ? t0 : ym + '-01');
  }
  var isAdmin = S.user && S.user.role === 'admin';
  v.append(h('div', { class: 'calhead' }, h('h2', null, first.toLocaleDateString(LOC(), { month: 'long', year: 'numeric', timeZone: 'UTC' })),
    h('div', { class: 'row' },
      h('button', { type: 'button', class: 'btn sm', 'aria-label': 'Vorheriger Monat', onclick: function () { shift(-1); } }, '‹'),
      h('button', { type: 'button', class: 'btn sm', onclick: function () { S.calMonth = t0.slice(0, 7); S.calDay = t0; render(); } }, 'Heute'),
      h('button', { type: 'button', class: 'btn sm', 'aria-label': 'Nächster Monat', onclick: function () { shift(1); } }, '›'))));
  v.append(h('div', { class: 'legend' }, Object.keys(TYPES).map(function (k) { return h('span', null, h('i', { class: 'dot ' + TYPES[k].cls }), TYPES[k].label); })));
  var grid = h('div', { class: 'cal' });
  ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].forEach(function (d) { grid.append(h('div', { class: 'wd' }, d)); });
  for (var i = 0; i < offset; i++) grid.append(h('div', { class: 'cell blank', 'aria-hidden': 'true' }));
  Array.from({ length: days }, function (_, k) { return k + 1; }).forEach(function (d) {
    var iso = ym + '-' + String(d).padStart(2, '0'), cs = by[iso] || [];
    grid.append(h('button', { type: 'button', class: 'cell' + (iso === t0 ? ' today' : '') + (iso === sel ? ' sel' : ''), 'aria-pressed': String(iso === sel),
      'aria-label': d + (S.lang === 'en' ? ' ' : '. ') + first.toLocaleDateString(LOC(), { month: 'long', timeZone: 'UTC' }) + ', ' + (cs.length ? cs.length + (cs.length === 1 ? ' Kurs' : ' Kurse') : 'keine Kurse'),
      onclick: function () { S.calDay = iso; render(); } },
      h('span', { class: 'n' }, d),
      h('span', { class: 'dots' }, cs.slice(0, 6).map(function (c) { return h('i', { class: 'dot ' + (TYPES[c.type] || TYPES.ohne).cls + (c.status === 'abgesagt' ? ' off' : '') }); })),
      cs.length > 6 ? h('span', { class: 'small muted' }, '+' + (cs.length - 6)) : null));
  });
  v.append(grid);
  var list = by[sel] || [];
  v.append(h('div', { class: 'row between' }, h('h3', null, dparts(sel).full),
    isAdmin ? h('button', { type: 'button', class: 'btn primary sm', onclick: function () { S.editing = { course: null, preset: { date: sel } }; render(); } }, 'Kurs an diesem Tag anlegen') : null));
  if (!list.length) { v.append(h('div', { class: 'panel' }, h('p', { class: 'muted' }, 'An diesem Tag gibt es keine Kurse.'))); return; }
  var box = h('div', { class: 'list' }); v.append(box);
  list.forEach(function (c) { var card = courseCard(c); box.append(isAdmin ? adminActions(card, c) : card); });
}

/* ---------- Team und Raum ---------- */
function viewTeam(v) {
  v.append(h('h2', null, 'Unser Team'));
  if (!S.trainers.length) { v.append(h('div', { class: 'panel' }, h('p', { class: 'muted' }, 'Hier erscheinen bald die Trainerinnen und Trainer.'))); return; }
  v.append(h('div', { class: 'team' }, S.trainers.map(function (t) {
    return h('article', { class: 'panel' }, h('h3', null, t.name), t.styles ? h('p', { class: 'muted small' }, t.styles) : null,
      t.dog_ok ? h('span', { class: 'chip dog' }, 'Erfahrung mit Hunden') : null, t.bio ? h('p', { class: 'prose' }, t.bio) : null);
  })));
}
function viewRaum(v) {
  var r = S.room || {};
  var facts = (r.facts || '').split('\n').map(function (l) { var i = l.indexOf(':'); return i > 0 ? [l.slice(0, i).trim(), l.slice(i + 1).trim()] : null; }).filter(Boolean);
  var rules = (r.rules || '').split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
  v.append(r.photo_url ? h('img', { class: 'photo', src: r.photo_url, alt: 'Foto vom Yogaraum' }) : h('div', { class: 'photo', role: 'img', 'aria-label': 'Foto folgt' }, 'Foto folgt'));
  v.append(h('div', { class: 'panel' }, h('h2', null, r.room_title || 'Der Raum'), h('p', { class: 'prose' }, r.body || 'Hier stellt das Studio seinen Raum vor.'),
    facts.length ? h('dl', { class: 'facts' }, facts.map(function (f) { return [h('dt', null, f[0]), h('dd', null, f[1])]; })) : null));
  if (rules.length) v.append(h('div', { class: 'panel' }, h('h3', null, 'Gut zu wissen'), h('ul', { class: 'plain' }, rules.map(function (x) { return h('li', null, x); }))));
  v.append(h('div', null, h('button', { type: 'button', class: 'btn primary', onclick: function () { go('kurse'); } }, 'Kurse ansehen')));
}

/* ---------- Meine Buchungen ---------- */
function viewBuchungen(v, r) {
  if (r.q.get('bezahlt')) v.append(h('div', { class: 'banner ok' }, 'Danke. Sobald die Zahlung bei uns eingegangen ist, steht sie hier als bezahlt.'));
  v.append(h('h2', null, 'Meine Buchungen'));
  if (!S.mine.length) { v.append(h('div', { class: 'panel' }, h('p', { class: 'muted' }, 'Du hast noch nichts gebucht.'), h('div', null, h('button', { type: 'button', class: 'btn primary', onclick: function () { go('kurse'); } }, 'Kurse ansehen')))); return; }
  var box = h('div', { class: 'list' }); v.append(box);
  S.mine.forEach(function (b) {
    var t = TYPES[b.type] || TYPES.ohne, hrs = (b.starts_at - Date.now()) / 36e5, past = hrs < 0, canCancel = hrs >= S.config.cancel_hours;
    var buttons = [];
    if (!past && b.status === 'ok' && b.pay_method === 'online' && b.pay_status === 'offen') {
      buttons.push(h('button', { type: 'button', class: 'btn primary sm', onclick: function () {
        api('POST', '/api/bookings/' + b.id + '/pay', {}).then(function (res) { window.location.href = res.pay_url; }).catch(function (e) { toast(e.message); });
      } }, 'Jetzt bezahlen'));
    }
    if (!past && b.status === 'ok' && b.pay_method === 'paypal' && b.pay_status === 'offen' && S.room && S.room.paypal_me) {
      buttons.push(h('a', { class: 'btn primary sm', target: '_blank', rel: 'noopener noreferrer',
        href: 'https://www.paypal.me/' + encodeURIComponent(S.room.paypal_me) + '/' + (b.price_cents * b.seats / 100).toFixed(2) + 'EUR' }, 'Mit PayPal bezahlen'));
    }
    if (!past) buttons.push(h('button', { type: 'button', class: 'btn sm danger', disabled: !canCancel, onclick: function () {
      act(function () { return api('POST', '/api/bookings/' + b.id + '/cancel', {}); }, 'Buchung storniert.').catch(function () {});
    } }, 'Stornieren'));
    box.append(h('article', { class: 'card nodate' },
      h('div', { class: 'info' }, h('span', { class: 'chip ' + t.cls }, t.label), h('h3', null, b.title),
        h('div', { class: 'meta' }, h('span', null, dparts(b.date).full + ', ' + b.time + ' Uhr'), h('span', null, b.seats + (b.seats === 1 ? ' Platz' : ' Plätze')), b.dog_name ? h('span', null, 'Hund: ' + b.dog_name) : null, h('span', null, euro(b.price_cents * b.seats))),
        h('div', { class: 'row' }, h('span', { class: 'chip ' + (past ? 'grey' : b.status === 'ok' ? 'ok' : 'warn') }, past ? 'Vorbei' : b.status === 'ok' ? 'Gebucht' : 'Warteliste'),
          h('span', { class: 'chip ' + (b.pay_status === 'bezahlt' ? 'ok' : 'grey') }, PAY[b.pay_method] + ' · ' + (b.pay_status === 'bezahlt' ? 'bezahlt' : 'offen')),
          b.course_status === 'abgesagt' ? h('span', { class: 'chip bad' }, 'Kurs abgesagt') : null),
        b.pay_method === 'ueberweisung' && b.pay_status === 'offen' && S.room && S.room.pay_info ? h('p', { class: 'small muted' }, 'Überweisung an: ' + S.room.pay_info) : null),
      h('div', { class: 'act' }, buttons, !past && !canCancel ? h('span', { class: 'small muted' }, 'Stornieren nur bis ' + S.config.cancel_hours + ' Std. vorher') : null)));
  });
}

/* ---------- Kursformular ---------- */
function courseForm(init, o) {
  var p = o.prefix;
  var d = Object.assign({ title: '', type: o.types[0], date: '', time: '18:00', dur: 60, cap: 8, price: 12, level: 'Alle Level', description: '', status: 'aktiv', trainer_id: '' }, init || {});
  if (d.price_cents != null) d.price = d.price_cents / 100;
  var C = {};
  C.title = h('input', { id: p + '-title', type: 'text', value: d.title, required: true, maxlength: 80 });
  C.type = h('select', { id: p + '-type', value: d.type }, o.types.map(function (k) { return h('option', { value: k }, TYPES[k].label); }));
  C.date = h('input', { id: p + '-date', type: 'date', value: d.date, required: true });
  C.time = h('input', { id: p + '-time', type: 'time', value: d.time, required: true });
  C.dur = h('input', { id: p + '-dur', type: 'number', min: 15, max: 240, step: 5, value: d.dur });
  C.cap = h('input', { id: p + '-cap', type: 'number', min: 1, max: 60, value: d.cap });
  C.price = h('input', { id: p + '-price', type: 'number', min: 0, max: 500, step: 0.5, value: d.price });
  C.level = h('select', { id: p + '-level', value: d.level }, LEVELS.map(function (l) { return h('option', { value: l }, l); }));
  C.status = h('select', { id: p + '-status', value: d.status }, [h('option', { value: 'aktiv' }, 'Findet statt'), h('option', { value: 'abgesagt' }, 'Abgesagt')]);
  C.desc = h('textarea', { id: p + '-desc', maxlength: 600 }, d.description);
  if (o.repeat) {
    C.every = h('select', { id: p + '-every' }, [h('option', { value: '' }, 'Nicht wiederholen'), h('option', { value: 'day' }, 'Jeden Tag'), h('option', { value: 'week' }, 'Jede Woche')]);
    C.until = h('input', { id: p + '-until', type: 'date' });
  }
  if (o.trainers) C.trainer = h('select', { id: p + '-trainer', value: d.trainer_id == null ? '' : String(d.trainer_id) },
    [h('option', { value: '' }, 'Studioleitung / kein Trainer')].concat(o.trainers.map(function (t) { return h('option', { value: String(t.id) }, t.name); })));
  var msg = h('p', { class: 'small', role: 'alert' });
  return afterInput(h('form', { class: 'panel stack', onsubmit: function (e) {
    e.preventDefault(); msg.textContent = '';
    var data = { title: C.title.value, type: C.type.value, date: C.date.value, time: C.time.value, dur: Number(C.dur.value), cap: Number(C.cap.value), price: Number(C.price.value), level: C.level.value, description: C.desc.value, status: C.status.value };
    if (C.every && C.every.value) {
      if (!C.until.value) { msg.textContent = 'Bitte ein Enddatum für die Wiederholung wählen.'; return; }
      data.repeat = { every: C.every.value, until: C.until.value };
    }
    if (C.trainer) data.trainer_id = C.trainer.value ? Number(C.trainer.value) : null;
    Promise.resolve(o.onSubmit(data)).catch(function (err) { msg.textContent = err.message; });
  } },
    h('h3', null, o.heading),
    fld('Titel', C.title),
    h('div', { class: 'grid2' }, fld('Kursart', C.type), fld('Niveau', C.level)),
    h('div', { class: 'grid2' }, fld('Datum', C.date), fld('Uhrzeit', C.time)),
    h('div', { class: 'grid2' }, fld('Dauer (Min.)', C.dur), fld('Plätze', C.cap), fld('Preis pro Platz (€)', C.price)),
    C.trainer ? fld('Trainer/in', C.trainer) : null,
    C.every ? h('div', { class: 'grid2' }, fld('Wiederholen', C.every), fld('Wiederholen bis (Datum)', C.until)) : null,
    fld('Beschreibung', C.desc), fld('Status', C.status), msg,
    h('div', { class: 'row' }, h('button', { type: 'submit', class: 'btn primary' }, o.submitLabel),
      h('button', { type: 'button', class: 'btn', onclick: function () { S.editing = null; render(); } }, 'Abbrechen'))));
}
function adminCourseForm() {
  var ed = S.editing, isEdit = ed.course && ed.course.id;
  return courseForm(ed.course || ed.preset, { prefix: 'ac', repeat: !isEdit, types: ['welpen', 'hund', 'ohne'], trainers: S.adm ? S.adm.trainers : [],
    heading: isEdit ? 'Kurs bearbeiten' : 'Neuer Kurs', submitLabel: 'Speichern',
    onSubmit: function (data) {
      return act(function () { return isEdit ? api('PUT', '/api/admin/courses/' + ed.course.id, data) : api('POST', '/api/admin/courses', data); }, data.repeat ? 'Serie angelegt.' : 'Gespeichert.').then(function () { S.editing = null; render(); });
    } });
}

/* ---------- Trainer ---------- */
function viewTrainer(v) {
  var u = S.user;
  if (u.role === 'admin') { v.append(h('div', { class: 'panel' }, h('p', { class: 'muted' }, 'Als Admin pflegst du Kurse direkt unter „Verwaltung“.'))); return; }
  if (u.role === 'customer') {
    v.append(h('h2', null, 'Trainer werden'));
    if (u.trainer_requested) { v.append(h('div', { class: 'panel' }, h('h3', null, 'Anfrage eingereicht'), h('p', { class: 'muted' }, 'Die Studioleitung prüft deine Anfrage. Danach kannst du hier dein Profil und deine Kurse pflegen.'))); return; }
    var bio = h('textarea', { id: 'tq-bio', maxlength: 700 });
    var dogOk = h('input', { id: 'tq-dog', type: 'checkbox' });
    v.append(afterInput(h('form', { class: 'panel stack', onsubmit: function (e) {
      e.preventDefault();
      api('POST', '/api/trainer-request', { bio: bio.value, dog_ok: dogOk.checked }).then(function () { return api('GET', '/api/me'); }).then(function (res) { S.user = res.user; S.formDirty = false; toast('Anfrage gesendet.'); render(); }).catch(function (err) { toast(err.message); });
    } },
      h('p', { class: 'muted' }, 'Als Trainer/in pflegst du dein Profil und schlägst Kurse vor. Die Studioleitung gibt jede Änderung frei, bis dahin bleibt die alte Version sichtbar.'),
      fld('Über dich und deine Ausbildung', bio),
      h('label', { class: 'check' }, dogOk, h('span', null, 'Ich habe Erfahrung mit Hunden oder eine Zusatzqualifikation.')),
      h('div', null, h('button', { type: 'submit', class: 'btn primary' }, 'Anfrage senden')))));
    return;
  }
  var tr = S.tr || { courses: [], proposals: [] };
  v.append(h('h2', null, 'Für Trainer'));
  v.append(h('div', { class: 'sub', role: 'group', 'aria-label': 'Trainerbereich' }, [['profil', 'Mein Profil'], ['kurse', 'Meine Kurse']].map(function (t) {
    return h('button', { type: 'button', 'aria-pressed': String(S.trainerTab === t[0]), onclick: function () { S.trainerTab = t[0]; S.editing = null; render(); } }, t[1]);
  })));
  if (S.trainerTab === 'profil') trainerProfile(v, tr); else trainerCourses(v, tr);
  if (tr.proposals.length) {
    v.append(h('h3', null, 'Deine Einreichungen'));
    var box = h('div', { class: 'list' }); v.append(box);
    tr.proposals.slice(0, 8).forEach(function (p) {
      box.append(h('div', { class: 'panel' },
        h('div', { class: 'row' }, h('b', null, p.kind === 'course' ? (p.data.title || 'Kurs') : 'Profiländerung'),
          h('span', { class: 'chip ' + (p.status === 'pending' ? 'warn' : p.status === 'approved' ? 'ok' : 'bad') }, p.status === 'pending' ? 'Wartet auf Freigabe' : p.status === 'approved' ? 'Freigegeben' : 'Abgelehnt')),
        p.reply ? h('p', { class: 'small' }, 'Antwort der Studioleitung: ' + p.reply) : null));
    });
  }
}
function trainerProfile(v, tr) {
  var u = S.user, pending = tr.proposals.some(function (p) { return p.kind === 'profile' && p.status === 'pending'; });
  var name = h('input', { id: 'tp-name', type: 'text', value: u.name, required: true, maxlength: 60 });
  var styles = h('input', { id: 'tp-styles', type: 'text', value: u.styles, maxlength: 120 });
  var bio = h('textarea', { id: 'tp-bio', maxlength: 700 }, u.bio);
  var dogOk = h('input', { id: 'tp-dog', type: 'checkbox', checked: u.dog_ok });
  v.append(afterInput(h('form', { class: 'panel stack', onsubmit: function (e) {
    e.preventDefault();
    act(function () { return api('POST', '/api/proposals', { kind: 'profile', data: { name: name.value, styles: styles.value, bio: bio.value, dog_ok: dogOk.checked } }); }, 'Zur Freigabe eingereicht.').catch(function () {});
  } },
    h('h3', null, 'Mein Profil'), h('p', { class: 'muted small' }, 'Bis zur Freigabe bleibt das bisherige Profil sichtbar.'),
    fld('Name', name), fld('Yoga-Stile', styles), fld('Über mich', bio),
    h('label', { class: 'check' }, dogOk, h('span', null, 'Erfahrung mit Hunden oder Zusatzqualifikation')),
    h('div', { class: 'row' }, h('button', { type: 'submit', class: 'btn primary' }, pending ? 'Neue Fassung einreichen' : 'Änderung einreichen'), pending ? h('span', { class: 'small muted' }, 'Eine frühere Änderung wartet noch. Sie wird ersetzt.') : null))));
}
function trainerCourses(v, tr) {
  if (S.editing) {
    var ed = S.editing;
    v.append(courseForm(ed.course, { prefix: 'tc', types: ['hund', 'ohne'], heading: ed.course ? 'Änderung vorschlagen' : 'Neuen Kurs vorschlagen', submitLabel: 'Zur Freigabe einreichen',
      onSubmit: function (data) {
        return act(function () { return api('POST', '/api/proposals', { kind: 'course', course_id: ed.course ? ed.course.id : undefined, data: data }); }, 'Zur Freigabe eingereicht.').then(function () { S.editing = null; render(); });
      } }));
    return;
  }
  v.append(h('div', null, h('button', { type: 'button', class: 'btn primary', onclick: function () { S.editing = { course: null }; render(); } }, 'Neuen Kurs vorschlagen')));
  if (!tr.courses.length) { v.append(h('div', { class: 'panel' }, h('p', { class: 'muted' }, 'Du hast noch keine freigegebenen Kurse. Schlage deinen ersten Kurs vor.'))); return; }
  var box = h('div', { class: 'list' }); v.append(box);
  tr.courses.forEach(function (c) {
    var pend = tr.proposals.some(function (p) { return p.kind === 'course' && p.course_id === c.id && p.status === 'pending'; });
    var card = courseCard(c);
    card.querySelector('.act').replaceChildren(h('b', null, euro(c.price_cents)),
      pend ? h('span', { class: 'chip warn' }, 'Änderung wartet') : h('button', { type: 'button', class: 'btn sm', onclick: function () { S.editing = { course: c }; render(); } }, 'Ändern'));
    box.append(card);
  });
}

/* ---------- Verwaltung ---------- */
function viewAdmin(v) {
  var u = S.user;
  if (u.role !== 'admin') { v.append(h('div', { class: 'banner bad' }, 'Dieser Bereich ist nur für die Studioleitung.')); return; }
  var a = S.adm || { proposals: [], trainerRequests: [], bookings: [], users: [], mails: [], trainers: [] };
  var tabs = [['freigaben', 'Freigaben', pendingCount()], ['kurse', 'Kurse'], ['buchungen', 'Buchungen'], ['nutzer', 'Konten'], ['raum', 'Raum und Studio'], ['rechtliches', 'Rechtliches'], ['mails', 'Mails']];
  v.append(h('h2', null, 'Verwaltung'));
  v.append(h('div', { class: 'sub', role: 'group', 'aria-label': 'Verwaltung' }, tabs.map(function (t) {
    return h('button', { type: 'button', 'aria-pressed': String(S.adminTab === t[0]), onclick: function () { S.adminTab = t[0]; S.editing = null; render(); } }, t[1], t[2] ? h('span', { class: 'count' }, '(' + t[2] + ')') : null);
  })));
  ({ freigaben: adminFreigaben, kurse: adminKurse, buchungen: adminBuchungen, nutzer: adminNutzer, raum: adminRaum, rechtliches: adminRecht, mails: adminMails })[S.adminTab](v, a);
}
function diffRows(p) {
  var labels = p.kind === 'course' ? COURSE_LABELS : PROFILE_LABELS, cur = p.current;
  var rows = Object.keys(labels).filter(function (k) { return !cur || String(cur[k] == null ? '' : cur[k]) !== String(p.data[k] == null ? '' : p.data[k]); }).map(function (k) {
    return h('li', null, h('b', null, labels[k] + ': '), cur && cur[k] != null && cur[k] !== '' ? [h('s', null, fmtVal(k, cur[k])), ' → '] : null, fmtVal(k, p.data[k]));
  });
  return rows.length ? rows : [h('li', null, 'Keine Unterschiede')];
}
function adminFreigaben(v, a) {
  if (!a.proposals.length && !a.trainerRequests.length) { v.append(h('div', { class: 'panel' }, h('h3', null, 'Alles erledigt'), h('p', { class: 'muted' }, 'Es warten keine Freigaben.'))); return; }
  a.trainerRequests.forEach(function (r) {
    v.append(h('div', { class: 'panel' },
      h('div', { class: 'row' }, h('b', null, r.name), h('span', { class: 'chip warn' }, 'Trainer-Anfrage'), h('span', { class: 'small muted' }, r.email)),
      r.bio ? h('p', { class: 'prose small' }, r.bio) : null,
      h('p', { class: 'small muted' }, r.dog_ok ? 'Gibt Erfahrung mit Hunden an.' : 'Keine Hundeerfahrung angegeben.'),
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'btn primary sm', onclick: function () { act(function () { return api('POST', '/api/admin/trainer-requests/' + r.id, { decision: 'approve' }); }, 'Trainer-Zugang freigegeben.').catch(function () {}); } }, 'Zugang freigeben'),
        h('button', { type: 'button', class: 'btn sm danger', onclick: function () { act(function () { return api('POST', '/api/admin/trainer-requests/' + r.id, { decision: 'reject' }); }, 'Abgelehnt.').catch(function () {}); } }, 'Ablehnen'))));
  });
  a.proposals.forEach(function (p) {
    var reply = h('input', { id: 'pr-' + p.id, type: 'text', maxlength: 300, placeholder: 'Antwort bei Ablehnung (optional)' });
    reply.addEventListener('input', function () { S.formDirty = true; });
    var dogWarn = p.kind === 'course' && p.data.type === 'hund' && p.current === null && false;
    v.append(h('div', { class: 'panel' },
      h('div', { class: 'row' }, h('b', null, p.kind === 'course' ? (p.course_id ? 'Kursänderung: ' : 'Neuer Kurs: ') + (p.data.title || '') : 'Profiländerung'), h('span', { class: 'chip grey' }, p.trainer_name)),
      dogWarn ? null : null,
      h('ul', { class: 'diff' }, diffRows(p)), reply,
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'btn primary sm', onclick: function () { act(function () { return api('POST', '/api/admin/proposals/' + p.id, { decision: 'approve', reply: reply.value }); }, 'Freigegeben.').catch(function () {}); } }, 'Freigeben'),
        h('button', { type: 'button', class: 'btn sm danger', onclick: function () { act(function () { return api('POST', '/api/admin/proposals/' + p.id, { decision: 'reject', reply: reply.value }); }, 'Abgelehnt.').catch(function () {}); } }, 'Ablehnen'))));
  });
}
function adminKurse(v) {
  if (S.editing) { v.append(adminCourseForm()); return; }
  v.append(h('div', null, h('button', { type: 'button', class: 'btn primary', onclick: function () { S.editing = { course: null }; render(); } }, 'Neuen Kurs anlegen')));
  if (!S.courses.length) { v.append(h('div', { class: 'panel' }, h('p', { class: 'muted' }, 'Noch keine Kurse angelegt.'))); return; }
  var box = h('div', { class: 'list' }); v.append(box);
  S.courses.forEach(function (c) { box.append(adminActions(courseCard(c), c)); });
}
function adminBuchungen(v, a) {
  var byCourse = {}, order = [];
  a.bookings.forEach(function (b) { if (!byCourse[b.course_id]) { byCourse[b.course_id] = []; order.push(b.course_id); } byCourse[b.course_id].push(b); });
  var upcoming = S.courses.filter(function (c) { return c.date >= todayISO(); });
  if (!upcoming.length) { v.append(h('div', { class: 'panel' }, h('p', { class: 'muted' }, 'Keine kommenden Kurse.'))); return; }
  upcoming.forEach(function (c) {
    var t = TYPES[c.type] || TYPES.ohne, bs = byCourse[c.id] || [];
    v.append(h('div', { class: 'panel' },
      h('div', { class: 'row' }, h('span', { class: 'chip ' + t.cls }, t.label), h('b', null, c.title)),
      h('p', { class: 'small muted' }, dparts(c.date).full + ', ' + c.time + ' Uhr · ' + c.taken + ' von ' + c.cap + ' Plätzen belegt'),
      bs.length ? h('div', { class: 'list' }, bs.map(function (b) {
        return h('div', { class: 'row between' },
          h('span', null, b.first_name + ' · ' + b.seats + '× ' + (b.dog_name ? '· Hund ' + b.dog_name + ' ' : ''), h('span', { class: 'chip ' + (b.status === 'ok' ? 'ok' : 'warn') }, b.status === 'ok' ? 'Gebucht' : 'Warteliste'), ' ',
            h('span', { class: 'chip ' + (b.pay_status === 'bezahlt' ? 'ok' : 'grey') }, PAY[b.pay_method] + ' · ' + (b.pay_status === 'bezahlt' ? 'bezahlt' : 'offen')), h('span', { class: 'small muted' }, ' · ' + b.email)),
          h('span', { class: 'row' },
            h('button', { type: 'button', class: 'btn sm', onclick: function () { act(function () { return api('POST', '/api/admin/bookings/' + b.id, { action: b.pay_status === 'bezahlt' ? 'unpaid' : 'paid' }); }).catch(function () {}); } }, b.pay_status === 'bezahlt' ? 'Als offen markieren' : 'Als bezahlt markieren'),
            b.status === 'wait' ? h('button', { type: 'button', class: 'btn sm', onclick: function () { act(function () { return api('POST', '/api/admin/bookings/' + b.id, { action: 'promote' }); }, 'Nachgerückt.').catch(function () {}); } }, 'Nachrücken') : null,
            h('button', { type: 'button', class: 'btn sm danger', onclick: function () { act(function () { return api('POST', '/api/admin/bookings/' + b.id, { action: 'remove' }); }, 'Buchung entfernt.').catch(function () {}); } }, 'Entfernen')));
      })) : h('p', { class: 'small muted' }, 'Noch keine Buchungen.')));
  });
}
function adminNutzer(v, a) {
  v.append(h('div', { class: 'panel' }, h('p', { class: 'muted small' }, 'Hier siehst du alle Konten. Über die Rolle bestimmst du, wer Trainer oder Admin ist. Neue Konten sind immer Kunden.'),
    h('div', { class: 'tablewrap' }, h('table', null,
      h('thead', null, h('tr', null, h('th', null, 'Name'), h('th', null, 'E-Mail'), h('th', null, 'Rolle'))),
      h('tbody', null, a.users.map(function (u) {
        var self = u.id === S.user.id;
        var sel = h('select', { id: 'role-' + u.id, 'aria-label': 'Rolle von ' + u.name, disabled: self, value: u.role }, Object.keys(ROLE_LABEL).map(function (k) { return h('option', { value: k }, ROLE_LABEL[k]); }));
        sel.addEventListener('change', function () { act(function () { return api('POST', '/api/admin/users/' + u.id + '/role', { role: sel.value }); }, 'Rolle geändert.').catch(function () { render(); }); });
        return h('tr', null, h('td', null, u.name || '–'), h('td', null, u.email, ' ', h('span', { class: 'chip ' + (u.email_verified ? 'ok' : 'warn') }, u.email_verified ? 'bestätigt' : 'nicht bestätigt')), h('td', null, sel));
      }))))));
}
function adminRaum(v) {
  var r = S.room || {}, F = {};
  F.studio_name = h('input', { id: 'rm-studio', type: 'text', value: r.studio_name || '', maxlength: 60, required: true });
  F.tagline = h('input', { id: 'rm-tag', type: 'text', value: r.tagline || '', maxlength: 140 });
  F.room_title = h('input', { id: 'rm-title', type: 'text', value: r.room_title || '', maxlength: 60 });
  F.body = h('textarea', { id: 'rm-text', maxlength: 2000 }, r.body || '');
  F.facts = h('textarea', { id: 'rm-facts', maxlength: 800 }, r.facts || '');
  F.rules = h('textarea', { id: 'rm-rules', maxlength: 1000 }, r.rules || '');
  F.paypal_me = h('input', { id: 'rm-paypal', type: 'text', value: r.paypal_me ? 'paypal.me/' + r.paypal_me : '', maxlength: 80 });
  F.pay_info = h('textarea', { id: 'rm-pay', maxlength: 400 }, r.pay_info || '');
  var file = h('input', { id: 'rm-photo', type: 'file', accept: 'image/png,image/jpeg,image/webp' });
  var photoMsg = h('span', { class: 'small muted' }, r.photo_url ? 'Foto hochgeladen.' : 'Noch kein Foto.');
  var photoBtn = h('button', { type: 'button', class: 'btn sm', onclick: function () {
    var f = file.files && file.files[0];
    if (!f) { toast('Bitte wähle zuerst ein Foto.'); return; }
    if (f.size > 5 * 1024 * 1024) { toast('Das Foto ist größer als 5 MB.'); return; }
    photoMsg.textContent = 'Lädt hoch …';
    act(function () { return api('POST', '/api/admin/room/photo', undefined, f); }, 'Foto gespeichert.').catch(function () { photoMsg.textContent = 'Upload nicht möglich.'; });
  } }, 'Foto hochladen');
  v.append(afterInput(h('form', { class: 'panel stack', onsubmit: function (e) {
    e.preventDefault();
    var body = {}; Object.keys(F).forEach(function (k) { body[k] = F[k].value; });
    act(function () { return api('PUT', '/api/admin/room', body); }, 'Gespeichert.').catch(function () {});
  } },
    h('h3', null, 'Raum und Studio'),
    fld('Name des Studios', F.studio_name), fld('Untertitel', F.tagline), fld('Überschrift Raum', F.room_title), fld('Beschreibung', F.body),
    fld('Eigenschaften', F.facts, 'Eine pro Zeile im Format „Titel: Wert“, zum Beispiel „Größe: 40 m²“.'),
    fld('Gut zu wissen', F.rules, 'Eine Regel oder ein Hinweis pro Zeile.'),
    fld('PayPal.me-Name oder -Link', F.paypal_me, 'Zum Beispiel paypal.me/deinname. Leer lassen, dann gibt es PayPal nicht zur Auswahl. Du markierst Buchungen selbst als bezahlt.'),
    fld('Zahlungshinweise', F.pay_info, 'Wird bei „Überweisung“ gezeigt, zum Beispiel IBAN und Verwendungszweck.'),
    h('div', { class: 'fld' }, h('span', { class: 'fl' }, 'Foto vom Raum'), h('div', { class: 'row' }, file, photoBtn, photoMsg)),
    h('div', null, h('button', { type: 'submit', class: 'btn primary' }, 'Speichern')))));
}
function adminRecht(v) {
  var L = (S.room && S.room.legal) || {}, F = {};
  var defs = [['imprint', 'Impressum'], ['privacy', 'Datenschutzerklärung'], ['terms', 'AGB und Stornobedingungen']];
  var fields = [];
  defs.forEach(function (d) {
    F[d[0]] = h('textarea', { id: 'lg-' + d[0], rows: 9, maxlength: 20000 }, L[d[0]] || '');
    F[d[0] + '_en'] = h('textarea', { id: 'lg-' + d[0] + '-en', rows: 9, maxlength: 20000 }, L[d[0] + '_en'] || '');
    fields.push(fld(d[1] + ' (Deutsch)', F[d[0]]), fld(d[1] + ' (Englisch, optional)', F[d[0] + '_en']));
  });
  v.append(afterInput(h('form', { class: 'panel stack', onsubmit: function (e) {
    e.preventDefault();
    var body = {}; Object.keys(F).forEach(function (k) { body[k] = F[k].value; });
    act(function () { return api('PUT', '/api/admin/legal', body); }, 'Gespeichert.').catch(function () {});
  } },
    h('h3', null, 'Rechtliche Texte'),
    h('p', { class: 'muted small' }, 'Diese Texte erscheinen unter „Impressum, Datenschutz, AGB“. Eine Leerzeile trennt Absätze. Der englische Text ist optional: Ist er leer, sehen Besucher auf Englisch den deutschen Text. Lass die Texte rechtlich prüfen.'),
    fields,
    h('div', null, h('button', { type: 'submit', class: 'btn primary' }, 'Speichern')))));
}
function adminMails(v, a) {
  v.append(h('div', { class: 'panel' },
    h('p', { class: 'muted small' }, S.config.mail ? 'E-Mails werden über Resend verschickt. Hier siehst du die letzten 30.' : 'Es ist kein Mail-Dienst eingerichtet. Die Mails werden nur hier aufgelistet und nicht verschickt.'),
    a.mails.length ? h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, h('th', null, 'Zeit'), h('th', null, 'An'), h('th', null, 'Betreff'), h('th', null, 'Status'))),
      h('tbody', null, a.mails.map(function (m) {
        return h('tr', null, h('td', null, new Date(m.created_at).toLocaleString(LOC())), h('td', null, m.to_email), h('td', null, m.subject),
          h('td', null, h('span', { class: 'chip ' + (m.sent ? 'ok' : m.error ? 'bad' : 'grey') }, m.sent ? 'versendet' : m.error ? 'Fehler' : 'nicht versendet')));
      })))) : h('p', { class: 'muted' }, 'Noch keine Mails.')));
}

/* ---------- Rechtliches ---------- */
function viewLegal(v) {
  var L = (S.room && S.room.legal) || {}, en = S.lang === 'en';
  v.append(h('h2', null, 'Impressum, Datenschutz und AGB'));
  var secs = [['Impressum', 'imprint', 'Name und Anschrift des Anbieters, E-Mail-Adresse, Telefonnummer, Steuernummer oder NIF, ggf. Registereintrag.'],
    ['Datenschutzerklärung', 'privacy', 'Welche Daten gespeichert werden (Name, E-Mail, Buchungen, Hundename), wofür, wie lange, an wen sie gehen (Hosting, Zahlungsdienst Stripe, Mail-Dienst Resend) und welche Rechte Nutzer haben.'],
    ['AGB und Stornobedingungen', 'terms', 'Kostenlose Stornierung bis ' + S.config.cancel_hours + ' Stunden vor Beginn, Regeln bei Absage durch das Studio, Haftung bei Hundekursen und Welpenterminen, Hausrecht (Ausschluss einzelner Hunde).']];
  var missing = secs.some(function (s) { return !L[s[1]]; });
  if (missing) v.append(h('div', { class: 'banner' }, 'Diese Texte sind Platzhalter. Bitte ersetze sie vor dem Start durch geprüfte Angaben (am besten mit Rechtsberatung).'));
  secs.forEach(function (s) {
    var txt = en && L[s[1] + '_en'] ? L[s[1] + '_en'] : L[s[1]];
    var box = h('div', { class: 'panel', id: 'legal-' + s[1] }, h('h3', null, s[0]));
    if (!txt) box.append(h('p', { class: 'prose' }, s[2]));
    else {
      if (en && !L[s[1] + '_en']) box.append(h('p', { class: 'small muted' }, 'Dieser Text liegt nur auf Deutsch vor.'));
      txt.split(/\n{2,}/).forEach(function (p) { if (p.trim()) box.append(h('p', { class: 'prose' }, p.trim())); });
    }
    v.append(box);
  });
}

/* ---------- Übersetzung (Englisch) ---------- */
var ATTRS = ['placeholder', 'aria-label', 'alt', 'title'];
function trText(n) {
  if (!n.parentNode || /^(TEXTAREA|SCRIPT|STYLE|INPUT)$/.test(n.parentNode.nodeName)) return;
  var t = window.EN.tr(n.nodeValue);
  if (t !== n.nodeValue) n.nodeValue = t;
}
function trAttr(e, a) {
  var v = e.getAttribute(a);
  if (!v) return;
  var t = window.EN.tr(v);
  if (t !== v) e.setAttribute(a, t);
}
function trWalk(n) {
  if (n.nodeType === 3) { trText(n); return; }
  if (n.nodeType !== 1 || /^(SCRIPT|STYLE)$/.test(n.nodeName)) return;
  ATTRS.forEach(function (a) { if (n.hasAttribute(a)) trAttr(n, a); });
  Array.prototype.forEach.call(n.childNodes, trWalk);
}
function startTranslator() {
  if (!window.EN || !window.MutationObserver) return;
  new MutationObserver(function (ms) {
    if (S.lang !== 'en') return;
    ms.forEach(function (m) {
      if (m.type === 'characterData') trText(m.target);
      else if (m.type === 'attributes') trAttr(m.target, m.attributeName);
      else Array.prototype.forEach.call(m.addedNodes, trWalk);
    });
    if (document.title) document.title = window.EN.tr(document.title);
  }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  if (S.lang === 'en') trWalk(document.body);
}

/* ---------- Start ---------- */
function init() {
  initLang(); startTranslator();
  Promise.all([api('GET', '/api/config'), api('GET', '/api/me')]).then(function (r) {
    S.config = r[0]; S.user = r[1].user;
    return Promise.all([loadPublic(), loadUserData()]);
  }).then(function () { S.ready = true; render(); }).catch(function (e) { S.error = 'Die Seite konnte nicht geladen werden. Bitte lade sie neu.'; render(); console.error(e); });
}
setInterval(function () {
  if (document.hidden || !S.ready || S.formDirty || !$('#modal').hidden) return;
  Promise.all([loadPublic(), loadUserData()]).then(function () { if (!S.formDirty && $('#modal').hidden) render(); }).catch(function () {});
}, 45000);
init();
})();
